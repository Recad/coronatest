import { Component, OnInit,ViewChild  } from '@angular/core';
import { ChartDataSets, ChartOptions } from 'chart.js';
import { Color, Label,BaseChartDirective } from 'ng2-charts';
import { FormControl } from '@angular/forms';


@Component({
  selector: 'app-graph',
  templateUrl: './graph.component.html',
  styleUrls: ['./graph.component.css']
  

})
export class GraphComponent implements OnInit {
  @ViewChild(BaseChartDirective) chart: BaseChartDirective;
  datatemp = [1,2,3,4,5,6];
  constructor() { }
  //Pare de formulario para cambiar tipo de grafica
  name = new FormControl('');

  CambiarGraph(valor) {
    //this.name.setValue('Nancy');
    //codigo para cambiar tipo de grafica
    this.chart.chart.data.datasets[0].data = [95, 72, 78, 75, 77, 75];
    //this.datatemp = [95, 72, 78, 75, 77, 75];

    this.chart.chart.update();
  }
  ngOnInit() {
		
  }

  lineChartData: ChartDataSets[] = [
    { data: this.datatemp, 
      label: 'Casos coronavirus Colombia' },
  ];

  lineChartLabels: Label[] = ['January', 'February', 'March', 'April', 'May', 'June'];

  lineChartOptions = {
    responsive: true,
  };

  lineChartColors: Color[] = [
    {
      borderColor: 'black',
      backgroundColor: 'rgba(255,255,0,0.28)',
    },
  ];

  lineChartLegend = true;
  lineChartPlugins = [];
  lineChartType = 'line';

}
